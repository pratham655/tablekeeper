
"use client";

import { useMemo, useState } from "react";
import dynamic from "next/dynamic";
import { matchesNaturalSearch, parseNaturalSearch } from "../lib/naturalSearch";

type Restaurant = {
  id: number;
  name: string;
  cuisine: string;
  location: string;
  rating: number;
  reviews: number;
  price: string;
  image: string;
  tags: string[];
};

type RestaurantMapProps = {
  restaurants: Restaurant[];
};

const RestaurantMap = dynamic<RestaurantMapProps>(
  () => import("../components/RestaurantMap"),
  {
    ssr: false,
    loading: () => (
      <div className="flex h-[480px] items-center justify-center rounded-[20px] bg-[#f1f2ec] text-sm text-[#777d73]">
        Loading restaurant map...
      </div>
    ),
  }
);

const restaurants: Restaurant[] = [
  {
    id: 1,
    name: "The Olive Table",
    cuisine: "Mediterranean",
    location: "Indiranagar, Bengaluru",
    rating: 4.8,
    reviews: 328,
    price: "₹₹₹",
    image:
      "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=80",
    tags: ["Romantic", "Fine Dining"],
  },
  {
    id: 2,
    name: "Spice Route",
    cuisine: "Indian",
    location: "Koramangala, Bengaluru",
    rating: 4.7,
    reviews: 512,
    price: "₹₹",
    image:
      "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=1200&q=80",
    tags: ["Popular", "Family"],
  },
  {
    id: 3,
    name: "Sakura House",
    cuisine: "Japanese",
    location: "MG Road, Bengaluru",
    rating: 4.9,
    reviews: 241,
    price: "₹₹₹₹",
    image:
      "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=1200&q=80",
    tags: ["Sushi", "Premium"],
  },
  {
    id: 4,
    name: "Casa Verde",
    cuisine: "Italian",
    location: "Whitefield, Bengaluru",
    rating: 4.6,
    reviews: 186,
    price: "₹₹₹",
    image:
      "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80",
    tags: ["Pizza", "Casual"],
  },
  {
    id: 5,
    name: "The Terrace",
    cuisine: "Continental",
    location: "HSR Layout, Bengaluru",
    rating: 4.7,
    reviews: 274,
    price: "₹₹₹",
    image:
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
    tags: ["Rooftop", "Dinner"],
  },
  {
    id: 6,
    name: "Chai & Co.",
    cuisine: "Indian",
    location: "Jayanagar, Bengaluru",
    rating: 4.5,
    reviews: 398,
    price: "₹₹",
    image:
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1200&q=80",
    tags: ["Casual", "Tea"],
  },
  {
    id: 7,
    name: "DRUMA",
    cuisine: "Multi-cuisine",
    location: "Jayanagar, Bengaluru",
    rating: 0,
    reviews: 0,
    price: "—",
    image:
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80",
    tags: ["Vegetarian", "Multi-cuisine"],
  },
];

const cuisines = [
  "All",
  "Indian",
  "Italian",
  "Japanese",
  "Mediterranean",
  "Continental",
  "Multi-cuisine",
];

function SearchIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      className="h-5 w-5"
      stroke="currentColor"
      strokeWidth="1.7"
    >
      <circle cx="10.8" cy="10.8" r="6.8" />
      <path d="m16 16 4.5 4.5" strokeLinecap="round" />
    </svg>
  );
}

function PinIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      className="h-5 w-5"
      stroke="currentColor"
      strokeWidth="1.7"
    >
      <path
        d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"
        strokeLinejoin="round"
      />
      <circle cx="12" cy="10" r="2.5" />
    </svg>
  );
}

export default function Home() {
  const [selectedCuisine, setSelectedCuisine] = useState("All");
  const [search, setSearch] = useState("");
  const [location, setLocation] = useState("");
  const [viewMode, setViewMode] = useState<"list" | "map">("list");

  const filteredRestaurants = useMemo(() => {
    const normalize = (value: string) =>
      value.toLowerCase().trim().replace(/\s+/g, " ");

    const intent = parseNaturalSearch(search);
    const locationText = normalize(location);

    return restaurants.filter((restaurant) => {
      const matchesCuisine =
        selectedCuisine === "All" ||
        restaurant.cuisine === selectedCuisine;

      const matchesSearch =
        !search.trim() || matchesNaturalSearch(restaurant, intent);

      const matchesLocation =
        !locationText ||
        normalize(restaurant.location).includes(locationText);

      return matchesCuisine && matchesSearch && matchesLocation;
    });
  }, [selectedCuisine, search, location]);

  const searchIntent = useMemo(
    () => parseNaturalSearch(search),
    [search]
  );

  function clearFilters() {
    setSelectedCuisine("All");
    setSearch("");
    setLocation("");
  }

  function scrollToRestaurants() {
    document
      .getElementById("restaurants")
      ?.scrollIntoView({ behavior: "smooth" });
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#f8f7f2] text-[#20251f]">
      {/* Navigation */}
      <header className="sticky top-0 z-50 border-b border-[#e9e7df] bg-[#f8f7f2]/95 backdrop-blur-xl">
        <div className="container-shell flex h-[76px] items-center justify-between">
          <a href="/" className="flex items-center gap-3" aria-label="Tablekeeper home">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#244b38] text-xl font-semibold text-white">
              t.
            </span>
            <span>
              <span className="block text-[19px] font-semibold leading-5 tracking-[-0.7px]">
                tablekeeper
              </span>
              <span className="mt-1 hidden text-[9px] font-semibold uppercase tracking-[2.2px] text-[#85877d] sm:block">
                A table worth keeping
              </span>
            </span>
          </a>

          <nav className="hidden items-center gap-9 md:flex">
            <a
              href="#restaurants"
              className="text-[13px] font-medium text-[#60665e] transition hover:text-[#244b38]"
            >
              Discover
            </a>
            <a
              href="#how-it-works"
              className="text-[13px] font-medium text-[#60665e] transition hover:text-[#244b38]"
            >
              How it works
            </a>
            <a
              href="/reservations"
              className="rounded-full border border-[#d9ddd4] px-5 py-2.5 text-[12px] font-semibold transition hover:border-[#244b38] hover:bg-[#244b38] hover:text-white"
            >
              My reservations
            </a>
          </nav>

          <a
            href="/reservations"
            className="rounded-full bg-[#244b38] px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-[#183727] md:hidden"
          >
            My bookings
          </a>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-[#244b38] text-white">
        <div className="pointer-events-none absolute -right-32 -top-44 h-[460px] w-[460px] rounded-full border border-white/[0.07]" />
        <div className="pointer-events-none absolute -right-12 -top-24 h-[300px] w-[300px] rounded-full border border-white/[0.07]" />
        <div className="pointer-events-none absolute -bottom-48 -left-32 h-[440px] w-[440px] rounded-full bg-[#173727]/60 blur-3xl" />

        <div className="container-shell relative grid gap-12 pb-20 pt-20 sm:pb-24 sm:pt-24 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:gap-16 lg:pb-28 lg:pt-28">
          <div className="max-w-[680px]">
            <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.07] px-3.5 py-2">
              <span className="h-1.5 w-1.5 rounded-full bg-[#d5b77b]" />
              <span className="text-[10px] font-semibold uppercase tracking-[2px] text-white/75">
                Good food. Beautiful moments.
              </span>
            </div>

            <h1 className="max-w-[680px] text-[52px] font-medium leading-[1.02] tracking-[-2.5px] sm:text-[68px] lg:text-[82px]">
              Make room for
              <br />
              <span className="font-serif italic text-[#d7c7a5]">
                something special.
              </span>
            </h1>

            <p className="mt-7 max-w-[440px] text-sm leading-7 text-white/65 sm:text-[15px]">
              Discover places worth gathering for. Find your next
              favourite table and make the moment yours.
            </p>

            <button
              onClick={scrollToRestaurants}
              className="mt-9 inline-flex min-h-12 items-center gap-3 rounded-full bg-[#f1eee4] px-6 text-[12px] font-bold text-[#244b38] transition hover:-translate-y-0.5 hover:bg-white"
            >
              Explore restaurants
              <span aria-hidden="true" className="text-base">↗</span>
            </button>

            <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 border-t border-white/15 pt-6">
              <div>
                <p className="text-xl font-medium tracking-tight">Curated</p>
                <p className="mt-1 text-[10px] uppercase tracking-[1.5px] text-white/45">
                  Dining experiences
                </p>
              </div>
              <div className="h-9 w-px bg-white/15" />
              <div>
                <p className="text-xl font-medium tracking-tight">Effortless</p>
                <p className="mt-1 text-[10px] uppercase tracking-[1.5px] text-white/45">
                  Table reservations
                </p>
              </div>
              <div className="h-9 w-px bg-white/15" />
              <div>
                <p className="text-xl font-medium tracking-tight">Thoughtful</p>
                <p className="mt-1 text-[10px] uppercase tracking-[1.5px] text-white/45">
                  Moments made easy
                </p>
              </div>
            </div>
          </div>

          {/* Straight, refined hero image */}
          <div className="mx-auto w-full max-w-[500px] lg:ml-auto">
            <div className="overflow-hidden rounded-[26px] border border-white/15 bg-[#345b45] shadow-[0_24px_65px_rgba(10,30,19,0.24)]">
              <div className="relative h-[320px] sm:h-[420px] lg:h-[480px]">
                <img
                  src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1400&q=85"
                  alt="An elegantly set restaurant dining table"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#10271c]/80 via-transparent to-black/10" />

                <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8">
                  <p className="text-[9px] font-semibold uppercase tracking-[2px] text-white/75">
                    The art of dining
                  </p>
                  <div className="mt-2 flex items-end justify-between gap-4">
                    <p className="font-serif text-2xl italic leading-tight text-white sm:text-[30px]">
                      A little more memorable.
                    </p>
                    <span className="mb-1 flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/40 bg-white/10 text-lg text-white backdrop-blur-md">
                      ↗
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Separate caption below the image */}
            <div className="mt-4 flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.07] px-5 py-4">
              <div>
                <p className="text-[9px] font-semibold uppercase tracking-[1.8px] text-white/50">
                  Your next outing
                </p>
                <p className="mt-1 text-[13px] font-medium text-white">
                  Starts with a table.
                </p>
              </div>
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/15 text-sm text-[#d7c7a5]">
                ✳
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Search panel */}
      <section className="container-shell relative z-10 -mt-1 pt-8 sm:pt-10">
        <div className="rounded-[22px] border border-[#e8e5db] bg-white p-3 shadow-[0_16px_50px_rgba(31,49,34,0.07)] sm:p-4">
          <div className="grid gap-2 md:grid-cols-[1fr_0.7fr_auto] md:items-center">
            <label className="flex min-h-[54px] items-center gap-3 rounded-xl bg-[#f7f7f3] px-4">
              <span className="text-[#858b80]"><SearchIcon /></span>
              <span className="min-w-0 flex-1">
                <span className="mb-1 block text-[9px] font-bold uppercase tracking-[1.5px] text-[#777d73]">
                  Find your place
                </span>
                <input
                  type="search"
                  aria-label="Search restaurants by name, cuisine, neighbourhood or experience"
                  autoComplete="off"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Try “vegetarian restaurant in Jayanagar”"
                  className="w-full bg-transparent text-[12px] text-[#20251f] outline-none placeholder:text-[#a2a59d]"
                />
              </span>
            </label>

            <label className="flex min-h-[54px] items-center gap-3 rounded-xl bg-[#f7f7f3] px-4">
              <span className="text-[#858b80]"><PinIcon /></span>
              <span className="min-w-0 flex-1">
                <span className="mb-1 block text-[9px] font-bold uppercase tracking-[1.5px] text-[#777d73]">
                  Neighbourhood
                </span>
                <input
                  type="search"
                  aria-label="Filter restaurants by neighbourhood"
                  autoComplete="off"
                  value={location}
                  onChange={(event) => setLocation(event.target.value)}
                  placeholder="Where are you dining?"
                  className="w-full bg-transparent text-[12px] text-[#20251f] outline-none placeholder:text-[#a2a59d]"
                />
              </span>
            </label>

            <button
              onClick={scrollToRestaurants}
              className="min-h-[54px] rounded-xl bg-[#244b38] px-8 text-[12px] font-bold text-white transition hover:bg-[#183727]"
            >
              Find a table <span className="ml-2">↗</span>
            </button>
          </div>
        </div>
      </section>

      {search.trim() && (
        <div className="container-shell pt-3">
          <p className="text-xs text-[#777d73]" aria-live="polite">
            Showing matches
            {searchIntent.vegetarian ? " · Vegetarian" : ""}
            {searchIntent.cuisine ? ` · ${searchIntent.cuisine}` : ""}
            {searchIntent.location ? ` · ${searchIntent.location}` : ""}
            {searchIntent.budgetFriendly ? " · Budget-friendly" : ""}
          </p>
        </div>
      )}

      {/* Cuisine filters */}
      <section className="container-shell pt-16 sm:pt-20">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#8b8e83]">
              A world of flavours
            </p>
            <h2 className="mt-2 font-serif text-3xl tracking-[-0.8px] text-[#20251f] sm:text-[38px]">
              Explore by cuisine
            </h2>
          </div>
          <p className="max-w-[300px] text-[12px] leading-6 text-[#85877e]">
            From familiar favourites to new discoveries, find a place
            that feels just right.
          </p>
        </div>

        <div className="mt-7 flex gap-2 overflow-x-auto pb-2">
          {cuisines.map((cuisine) => {
            const active = selectedCuisine === cuisine;
            return (
              <button
                key={cuisine}
                onClick={() => setSelectedCuisine(cuisine)}
                aria-pressed={active}
                className={`shrink-0 rounded-full border px-5 py-3 text-[11px] font-semibold transition ${
                  active
                    ? "border-[#244b38] bg-[#244b38] text-white"
                    : "border-[#e5e3da] bg-white text-[#686e65] hover:border-[#244b38] hover:text-[#244b38]"
                }`}
              >
                {cuisine}
              </button>
            );
          })}
        </div>
      </section>

      {/* Restaurant collection */}
      <section id="restaurants" className="container-shell scroll-mt-28 pb-20 pt-9 sm:pb-24">
        <div className="flex items-end justify-between gap-4 border-b border-[#e5e3da] pb-5">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#8b8e83]">
              The Tablekeeper edit
            </p>
            <h2 className="mt-2 font-serif text-3xl tracking-[-0.8px] sm:text-[38px]">
              Places to gather
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="pb-1 text-[11px] text-[#85877e]">
              {filteredRestaurants.length}{" "}
              {filteredRestaurants.length === 1 ? "place" : "places"}
            </span>
            <div className="inline-flex rounded-full border border-[#e5e3da] bg-white p-1" aria-label="Restaurant view">
              <button
                type="button"
                onClick={() => setViewMode("list")}
                aria-pressed={viewMode === "list"}
                className={`rounded-full px-4 py-2 text-[11px] font-semibold transition ${viewMode === "list" ? "bg-[#244b38] text-white" : "text-[#686e65] hover:text-[#244b38]"}`}
              >
                List
              </button>
              <button
                type="button"
                onClick={() => setViewMode("map")}
                aria-pressed={viewMode === "map"}
                className={`rounded-full px-4 py-2 text-[11px] font-semibold transition ${viewMode === "map" ? "bg-[#244b38] text-white" : "text-[#686e65] hover:text-[#244b38]"}`}
              >
                Map
              </button>
            </div>
          </div>
        </div>

        {filteredRestaurants.length === 0 ? (
          <div className="mt-8 rounded-[22px] border border-dashed border-[#d9d8cf] bg-white px-5 py-16 text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[#f1f2ec] text-xl">
              <SearchIcon />
            </div>
            <h3 className="mt-5 font-serif text-2xl">No places found</h3>
            <p className="mt-2 text-[12px] text-[#85877e]">
              Try another search or clear your filters.
            </p>
            <button
              onClick={clearFilters}
              className="mt-6 rounded-full bg-[#244b38] px-5 py-3 text-[11px] font-semibold text-white transition hover:bg-[#183727]"
            >
              Clear filters
            </button>
          </div>
        ) : (
          viewMode === "map" ? (
            <div className="mt-8 overflow-hidden rounded-[20px] border border-[#e5e3da] bg-white p-2 shadow-[0_12px_40px_rgba(31,49,34,0.06)]">
              <RestaurantMap restaurants={filteredRestaurants} />
              <p className="px-3 pb-2 pt-3 text-[10px] leading-5 text-[#85877e]">
                Map pins show approximate neighbourhood locations for this demo, not verified restaurant coordinates.
              </p>
            </div>
          ) : (
            <div className="mt-8 grid gap-x-7 gap-y-11 sm:grid-cols-2 lg:grid-cols-3">
              {filteredRestaurants.map((restaurant, index) => (
              <article key={restaurant.id} className="group interactive-card min-w-0">
                <a
                  href={`/restaurants/${restaurant.id}`}
                  aria-label={`View ${restaurant.name}`}
                  className="relative block aspect-[1.35/1] overflow-hidden rounded-[20px] bg-[#e8e8df]"
                >
                  <img
                    src={restaurant.image}
                    alt={restaurant.name}
                    loading={index > 2 ? "lazy" : "eager"}
                    className="h-full w-full object-cover transition duration-700 ease-out group-hover:scale-[1.06]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-black/10 opacity-80" />
                  <div className="absolute left-4 top-4 flex flex-wrap gap-2">
                    {restaurant.tags.slice(0, 2).map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full border border-white/40 bg-[#fbfaf6]/90 px-3 py-1.5 text-[9px] font-bold tracking-wide text-[#30382f] backdrop-blur-md"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <span className="absolute right-4 top-4 flex items-center gap-1 rounded-full bg-[#fbfaf6] px-3 py-1.5 text-[10px] font-bold text-[#20251f] shadow-sm">
                    <span className="text-[#b48a43]">★</span>{" "}
                    {restaurant.rating.toFixed(1)}
                  </span>
                  <span className="absolute bottom-4 right-4 flex h-10 w-10 translate-y-2 items-center justify-center rounded-full bg-[#fbfaf6] text-lg text-[#244b38] opacity-0 shadow-lg transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
                    ↗
                  </span>
                </a>

                <div className="px-1 pt-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <a
                        href={`/restaurants/${restaurant.id}`}
                        className="font-serif text-[22px] tracking-[-0.4px] transition hover:text-[#477052]"
                      >
                        {restaurant.name}
                      </a>
                      <p className="mt-1 text-[11px] text-[#85877e]">
                        {restaurant.cuisine} <span className="mx-1.5">·</span>{" "}
                        {restaurant.price}
                      </p>
                    </div>
                    <span className="shrink-0 pt-1 text-[10px] text-[#85877e]">
                      {restaurant.reviews} reviews
                    </span>
                  </div>

                  <div className="mt-3 flex items-center gap-2 text-[11px] text-[#777d73]">
                    <span className="text-[#9a9d92]"><PinIcon /></span>
                    {restaurant.location}
                  </div>

                  <a
                    href={`/restaurants/${restaurant.id}`}
                    className="mt-5 flex min-h-11 items-center justify-between border-t border-[#e8e6dd] pt-3 text-[11px] font-bold text-[#244b38] transition hover:text-[#65836b]"
                  >
                    Explore restaurant
                    <span className="text-base transition-transform group-hover:translate-x-1">
                      →
                    </span>
                  </a>
                </div>
              </article>
              ))}
            </div>
          )
        )}
      </section>

      {/* Brand statement */}
      <section id="how-it-works" className="border-y border-[#e9e7df] bg-[#efeee6]">
        <div className="container-shell py-16 sm:py-20">
          <div className="mx-auto max-w-[650px] text-center">
            <p className="text-[10px] font-bold uppercase tracking-[2px] text-[#81877c]">
              The Tablekeeper way
            </p>
            <h2 className="mt-4 font-serif text-3xl leading-tight tracking-[-1px] sm:text-[44px]">
              Less planning. More{" "}
              <span className="italic text-[#55735b]">being there.</span>
            </h2>
            <p className="mx-auto mt-5 max-w-[480px] text-[13px] leading-7 text-[#777d73]">
              Finding a table should be the easiest part of a good
              evening. Discover a place, choose your moment, and
              look forward to what comes next.
            </p>
          </div>

          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {[
              {
                number: "01",
                title: "Find your place",
                description:
                  "Explore restaurants by cuisine, neighbourhood, or the kind of experience you have in mind.",
                symbol: "⌕",
              },
              {
                number: "02",
                title: "Choose your moment",
                description:
                  "Select your date, party size, and preferred time to explore available options.",
                symbol: "◷",
              },
              {
                number: "03",
                title: "Make it yours",
                description:
                  "Complete your reservation and keep your dining plans together in one place.",
                symbol: "✳",
              },
            ].map((item) => (
              <div
                key={item.number}
                className="rounded-[18px] border border-[#e1e0d6] bg-[#f8f7f2] p-7 sm:p-8"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold tracking-[1.5px] text-[#8b8e83]">
                    {item.number}
                  </span>
                  <span className="text-2xl text-[#55735b]">
                    {item.symbol}
                  </span>
                </div>
                <h3 className="mt-8 font-serif text-[22px]">{item.title}</h3>
                <p className="mt-3 text-[12px] leading-6 text-[#85877e]">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1d3d2c] text-white">
        <div className="container-shell flex flex-col gap-8 py-10 sm:flex-row sm:items-center sm:justify-between">
          <a href="/" className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#f1eee4] text-lg font-semibold text-[#244b38]">
              t.
            </span>
            <span>
              <span className="block text-[16px] font-semibold tracking-[-0.5px]">
                tablekeeper
              </span>
              <span className="mt-1 block text-[9px] uppercase tracking-[1.5px] text-white/45">
                A table worth keeping
              </span>
            </span>
          </a>

          <div className="flex flex-wrap gap-x-6 gap-y-3 text-[11px] text-white/65">
            <a href="#restaurants" className="transition hover:text-white">
              Discover
            </a>
            <a href="#how-it-works" className="transition hover:text-white">
              How it works
            </a>
            <a href="/reservations" className="transition hover:text-white">
              My reservations
            </a>
          </div>

          <p className="text-[10px] text-white/40">© 2026 Tablekeeper</p>
        </div>
      </footer>
    </main>
  );
}