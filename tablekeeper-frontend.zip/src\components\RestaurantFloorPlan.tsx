
"use client";

type RestaurantTable = {
  id: string;
  name: string;
  capacity: number;
  section: string;
  unavailable?: boolean;
};

type Props = {
  guests: number;
  selectedTableId: string;
  onSelect: (table: RestaurantTable) => void;
  unavailableTableIds?: string[];
};

const tables: RestaurantTable[] = [
  { id: "T1", name: "Table 1", capacity: 2, section: "A" },
  { id: "T2", name: "Table 2", capacity: 4, section: "A" },
  { id: "T3", name: "Table 3", capacity: 2, section: "A" },
  { id: "T4", name: "Table 4", capacity: 4, section: "B" },
  { id: "T5", name: "Table 5", capacity: 6, section: "B" },
  { id: "T6", name: "Table 6", capacity: 4, section: "B" },
  { id: "T7", name: "Table 7", capacity: 2, section: "C" },
  { id: "T8", name: "Table 8", capacity: 4, section: "C" },
  { id: "T9", name: "Table 9", capacity: 6, section: "C" },
];

export default function RestaurantFloorPlan({
  guests,
  selectedTableId,
  onSelect,
  unavailableTableIds = [],
}: Props) {
  const sections = ["A", "B", "C"];

  return (
    <section className="mt-6 rounded-[24px] border border-[#e5e3da] bg-[#fbfaf6] p-4 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[1.8px] text-[#85877e]">
            Choose your seating
          </p>
          <h2 className="mt-2 font-serif text-2xl text-[#20251f] sm:text-3xl">
            Select a table
          </h2>
          <p className="mt-2 text-sm text-[#777d73]">
            Choose a table that can accommodate {guests}{" "}
            {guests === 1 ? "guest" : "guests"}.
          </p>
        </div>

        <div className="flex flex-wrap gap-3 text-[11px] text-[#697066]">
          <span className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-sm bg-[#39834e]" />
            Available
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-sm bg-[#d49b3e]" />
            Selected
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-sm bg-[#b5b5b0]" />
            Unavailable
          </span>
        </div>
      </div>

      <div className="mt-6 rounded-xl border border-dashed border-[#d5d7ce] bg-white px-3 py-3 text-center">
        <span className="text-[10px] font-bold uppercase tracking-[2px] text-[#8a8e84]">
          Window side
        </span>
      </div>

      <div className="mt-5 space-y-6">
        {sections.map((section) => {
          const sectionTables = tables.filter(
            (table) => table.section === section
          );

          return (
            <div key={section}>
              <div className="mb-3 flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#e9eee7] text-[10px] font-bold text-[#244b38]">
                  {section}
                </span>
                <span className="text-[10px] font-bold uppercase tracking-[1.5px] text-[#85877e]">
                  Section {section}
                </span>
                <div className="h-px flex-1 bg-[#e8e6dd]" />
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {sectionTables.map((table) => {
                  const unavailable =
                    table.unavailable ||
                    unavailableTableIds.includes(table.id);
                  const tooSmall = table.capacity < guests;
                  const disabled = unavailable || tooSmall;
                  const selected = selectedTableId === table.id;

                  return (
                    <button
                      key={table.id}
                      type="button"
                      disabled={disabled}
                      onClick={() => onSelect(table)}
                      aria-pressed={selected}
                      aria-label={`${table.name}, seats ${table.capacity}, ${
                        unavailable
                          ? "unavailable"
                          : tooSmall
                          ? "not enough seats"
                          : selected
                          ? "selected"
                          : "available"
                      }`}
                      className={`group flex min-h-[142px] flex-col items-center justify-center rounded-2xl border-2 p-3 text-center transition duration-200 ${
                        selected
                          ? "border-[#d49b3e] bg-[#fff5df] shadow-md"
                          : disabled
                          ? "cursor-not-allowed border-[#e0e0db] bg-[#f0f0ed] opacity-70"
                          : "border-[#dce6db] bg-white hover:-translate-y-0.5 hover:border-[#39834e] hover:shadow-md"
                      }`}
                    >
                      <span
                        className={`flex h-12 w-12 items-center justify-center rounded-xl transition ${
                          selected
                            ? "bg-[#f5dfad] text-[#855d16]"
                            : disabled
                            ? "bg-[#e1e1dc] text-[#999b94]"
                            : "bg-[#eaf2e9] text-[#39834e] group-hover:bg-[#dcebdc]"
                        }`}
                      >
                        <svg
                          viewBox="0 0 48 48"
                          className="h-8 w-8"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          aria-hidden="true"
                        >
                          <rect x="10" y="10" width="28" height="28" rx="7" />
                          <path d="M17 5v5M31 5v5M17 38v5M31 38v5M5 17h5M5 31h5M38 17h5M38 31h5" />
                        </svg>
                      </span>

                      <span className="mt-2 text-sm font-semibold text-[#20251f]">
                        {table.name}
                      </span>
                      <span className="mt-1 text-xs text-[#777d73]">
                        {table.capacity} seats
                      </span>

                      <span
                        className={`mt-2 rounded-full px-2.5 py-1 text-[10px] font-semibold ${
                          selected
                            ? "bg-[#f5dfad] text-[#855d16]"
                            : unavailable
                            ? "bg-[#e1e1dc] text-[#777870]"
                            : tooSmall
                            ? "bg-[#f0f0ed] text-[#777870]"
                            : "bg-[#e7f2e7] text-[#39834e]"
                        }`}
                      >
                        {selected
                          ? "Selected"
                          : unavailable
                          ? "Unavailable"
                          : tooSmall
                          ? "Too small"
                          : "Available"}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 rounded-xl border border-[#e5e3da] bg-white p-4">
        {selectedTableId ? (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[1.3px] text-[#85877e]">
                Your selection
              </p>
              <p className="mt-1 text-sm font-semibold text-[#244b38]">
                {tables.find((table) => table.id === selectedTableId)?.name ??
                  selectedTableId}
              </p>
              <p className="mt-1 text-xs text-[#777d73]">
                {tables.find((table) => table.id === selectedTableId)?.capacity ??
                  0}{" "}
                seats
              </p>
            </div>
            <button
              type="button"
              onClick={() => onSelect({ id: "", name: "", capacity: 0, section: "" })}
              className="text-xs font-semibold text-[#777d73] underline underline-offset-4 hover:text-[#244b38]"
            >
              Clear selection
            </button>
          </div>
        ) : (
          <p className="text-center text-sm text-[#85877e]">
            Select an available table to continue.
          </p>
        )}
      </div>

      <p className="mt-4 text-center text-[10px] leading-5 text-[#999b92]">
        Sample floor plan and availability for the prototype. Live table
        availability will be verified by the backend.
      </p>
    </section>
  );
}