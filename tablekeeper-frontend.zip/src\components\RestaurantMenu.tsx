
"use client";

import { useMemo, useState } from "react";
import {
  restaurantMenus,
  type MenuCategory,
  type MenuItem,
} from "../data/menu-data";

type Props = {
  restaurantId: string;
};

const categories: Array<"All" | MenuCategory> = [
  "All",
  "Starters",
  "Mains",
  "Sides",
  "Desserts",
  "Beverages",
];

const categoryIcons: Record<MenuCategory, string> = {
  Starters: "🥗",
  Mains: "🍽️",
  Sides: "🥖",
  Desserts: "🍰",
  Beverages: "🥤",
};

export default function RestaurantMenu({ restaurantId }: Props) {
  const [activeCategory, setActiveCategory] = useState<
    "All" | MenuCategory
  >("All");
  const [search, setSearch] = useState("");
  const [diet, setDiet] = useState<"all" | "veg" | "nonveg">("all");

  const menu: MenuItem[] = restaurantMenus[restaurantId] ?? [];

  const filteredItems = useMemo(() => {
    const query = search.trim().toLowerCase();

    return menu.filter((item) => {
      const matchesCategory =
        activeCategory === "All" || item.category === activeCategory;

      const matchesSearch =
        query.length === 0 ||
        item.name.toLowerCase().includes(query) ||
        item.category.toLowerCase().includes(query);

      const matchesDiet =
        diet === "all" ||
        (diet === "veg" && item.vegetarian) ||
        (diet === "nonveg" && !item.vegetarian);

      return matchesCategory && matchesSearch && matchesDiet;
    });
  }, [menu, activeCategory, search, diet]);

  return (
    <section
      id="menu"
      className="mt-12 border-t border-[#e5e3da] pt-9"
    >
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[1.8px] text-[#85877e]">
            A taste of the experience
          </p>

          <h2 className="mt-2 font-serif text-3xl tracking-[-0.7px] text-[#20251f] sm:text-4xl">
            Explore the menu
          </h2>

          <p className="mt-2 text-sm text-[#777d73]">
            Discover the dishes available at this restaurant.
          </p>
        </div>

        <span className="rounded-full border border-[#e5e3da] bg-white px-4 py-2 text-xs font-semibold text-[#536052]">
          {menu.length} dishes
        </span>
      </div>

      <div className="mt-7 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-lg text-[#85877e]">
            ⌕
          </span>

          <input
            type="search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search dishes..."
            aria-label="Search menu"
            className="h-12 w-full rounded-full border border-[#e5e3da] bg-white pl-11 pr-5 text-sm text-[#20251f] outline-none transition placeholder:text-[#a2a49b] focus:border-[#55735b] focus:ring-2 focus:ring-[#55735b]/10"
          />
        </div>

        <select
          value={diet}
          onChange={(event) =>
            setDiet(event.target.value as "all" | "veg" | "nonveg")
          }
          aria-label="Filter by dietary preference"
          className="h-12 rounded-full border border-[#e5e3da] bg-white px-5 text-sm text-[#30382f] outline-none focus:border-[#55735b]"
        >
          <option value="all">All dishes</option>
          <option value="veg">Vegetarian</option>
          <option value="nonveg">Non-vegetarian</option>
        </select>
      </div>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-2">
        {categories.map((category) => {
          const selected = activeCategory === category;

          return (
            <button
              key={category}
              type="button"
              onClick={() => setActiveCategory(category)}
              aria-pressed={selected}
              className={`shrink-0 rounded-full px-5 py-2.5 text-xs font-semibold transition ${
                selected
                  ? "bg-[#244b38] text-white shadow-sm"
                  : "border border-[#e5e3da] bg-white text-[#697066] hover:border-[#9eae9f] hover:text-[#244b38]"
              }`}
            >
              {category === "All"
                ? "All items"
                : `${categoryIcons[category]} ${category}`}
            </button>
          );
        })}
      </div>

      {filteredItems.length > 0 ? (
        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {filteredItems.map((item) => (
            <article
              key={item.id}
              className="group flex min-h-[154px] flex-col justify-between rounded-[18px] border border-[#e8e6dd] bg-white p-5 transition duration-300 hover:-translate-y-1 hover:border-[#cbd5c9] hover:shadow-[0_12px_30px_rgba(30,45,32,0.07)]"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <span className="text-[9px] font-bold uppercase tracking-[1.4px] text-[#92968b]">
                    {item.category}
                  </span>

                  <h3 className="mt-2 font-serif text-lg leading-snug text-[#20251f]">
                    {item.name}
                  </h3>
                </div>

                <span
                  title={
                    item.vegetarian
                      ? "Vegetarian"
                      : "Non-vegetarian"
                  }
                  aria-label={
                    item.vegetarian
                      ? "Vegetarian"
                      : "Non-vegetarian"
                  }
                  className={`mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-[4px] border ${
                    item.vegetarian
                      ? "border-[#43844b]"
                      : "border-[#b84b42]"
                  }`}
                >
                  <span
                    className={`h-2 w-2 rounded-full ${
                      item.vegetarian
                        ? "bg-[#43844b]"
                        : "bg-[#b84b42]"
                    }`}
                  />
                </span>
              </div>

              <div className="mt-5 flex items-end justify-between gap-2">
                <span className="text-[10px] text-[#92968b]">
                  {item.vegetarian
                    ? "Vegetarian"
                    : "Non-vegetarian"}
                </span>

                <span className="text-sm font-bold tabular-nums text-[#244b38]">
                  ₹{item.price.toLocaleString("en-IN")}
                </span>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="mt-5 rounded-[18px] border border-dashed border-[#d9ddd4] bg-white/70 px-5 py-12 text-center">
          <div className="text-3xl" aria-hidden="true">
            🍽️
          </div>

          <h3 className="mt-3 font-serif text-xl text-[#30382f]">
            No dishes found
          </h3>

          <p className="mt-2 text-sm text-[#85877e]">
            Try another search or change your filters.
          </p>

          <button
            type="button"
            onClick={() => {
              setSearch("");
              setActiveCategory("All");
              setDiet("all");
            }}
            className="mt-5 rounded-full bg-[#244b38] px-5 py-2.5 text-xs font-semibold text-white transition hover:bg-[#183727]"
          >
            Clear filters
          </button>
        </div>
      )}

      <p className="mt-5 text-[10px] leading-5 text-[#999b92]">
        Menu items and prices are sample data for this prototype.
        Please confirm current availability and pricing with the
        restaurant.
      </p>
    </section>
  );
}