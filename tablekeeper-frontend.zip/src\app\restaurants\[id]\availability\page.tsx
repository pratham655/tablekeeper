
"use client";

import { Suspense, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import RestaurantFloorPlan from "../../../../components/RestaurantFloorPlan";

const restaurantNames: Record<string, string> = {
  "1": "The Olive Table",
  "2": "Spice Route",
  "3": "Sakura House",
  "4": "Casa Verde",
  "5": "The Terrace",
  "6": "Chai & Co.",
  "7": "DRUMA",
};

const reservationTimes = [
  { value: "12:00", label: "12:00 PM" },
  { value: "12:30", label: "12:30 PM" },
  { value: "13:00", label: "1:00 PM" },
  { value: "13:30", label: "1:30 PM" },
  { value: "14:00", label: "2:00 PM" },
  { value: "18:00", label: "6:00 PM" },
  { value: "18:30", label: "6:30 PM" },
  { value: "19:00", label: "7:00 PM" },
  { value: "19:30", label: "7:30 PM" },
  { value: "20:00", label: "8:00 PM" },
  { value: "20:30", label: "8:30 PM" },
  { value: "21:00", label: "9:00 PM" },
];

function getTodayLocal(): string {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function getSafeGuests(value: string | null): number {
  const guests = Number(value ?? "2");

  if (!Number.isFinite(guests) || guests < 1) {
    return 2;
  }

  return Math.min(guests, 6);
}

function AvailabilityContent() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const searchParams = useSearchParams();

  const restaurantId = params.id;
  const restaurantName = restaurantNames[restaurantId] ?? "Restaurant";

  const today = getTodayLocal();

  const [date, setDate] = useState(
    searchParams.get("date") || today
  );

  const [time, setTime] = useState(
    searchParams.get("time") || "19:00"
  );

  const [guests, setGuests] = useState(
    getSafeGuests(searchParams.get("guests"))
  );

  const [selectedTableId, setSelectedTableId] = useState(
    searchParams.get("table") || ""
  );

  const [error, setError] = useState("");

  const handleDateChange = (value: string) => {
    setDate(value);
    setSelectedTableId("");
    setError("");
  };

  const handleTimeChange = (value: string) => {
    setTime(value);
    setSelectedTableId("");
    setError("");
  };

  const handleGuestsChange = (value: string) => {
    setGuests(Number(value));
    setSelectedTableId("");
    setError("");
  };

  const handleTableSelect = (table: { id: string }) => {
    setSelectedTableId(table.id);
    setError("");
  };

  const handleContinue = () => {
    setError("");

    if (!date) {
      setError("Please select a reservation date.");
      return;
    }

    if (date < today) {
      setError("Please select today or a future date.");
      return;
    }

    if (!time) {
      setError("Please select a reservation time.");
      return;
    }

    if (!selectedTableId) {
      setError("Please select an available table to continue.");
      return;
    }

    const query = new URLSearchParams({
      date,
      time,
      guests: String(guests),
      table: selectedTableId,
    });

    router.push(
      `/restaurants/${restaurantId}/reservation?${query.toString()}`
    );
  };

  return (
    <main className="min-h-screen bg-[#f8f8f3] px-4 pb-16 pt-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl">
        {/* Back navigation */}
        <button
          type="button"
          onClick={() => router.back()}
          className="mb-6 inline-flex items-center gap-2 text-sm font-medium text-[#697066] transition hover:text-[#244b38]"
        >
          <span aria-hidden="true">←</span>
          Back to restaurant
        </button>

        {/* Reservation details */}
        <section className="relative overflow-hidden rounded-[24px] border border-[#e5e3da] bg-white p-5 shadow-sm sm:p-8">
          <div
            aria-hidden="true"
            className="float-decoration pointer-events-none absolute right-6 top-20"
          >
            <div className="citrus-decoration h-16 w-16 opacity-60" />
          </div>
          <div className="relative z-10">
            <p className="text-[10px] font-bold uppercase tracking-[1.8px] text-[#85877e]">
              Tablekeeper reservations
            </p>

            <h1 className="mt-2 font-serif text-3xl tracking-[-0.7px] text-[#20251f] sm:text-4xl">
              Book your table
            </h1>

            <p className="mt-2 text-sm text-[#777d73]">
              Select your preferred date, time, guests and seating at{" "}
              <span className="font-semibold text-[#244b38]">
                {restaurantName}
              </span>
              .
            </p>
          </div>

          {/* Reservation inputs */}
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {/* Date */}
            <label className="block">
              <span className="mb-2 block text-xs font-semibold text-[#4d554b]">
                Reservation date
              </span>

              <input
                type="date"
                value={date}
                min={today}
                onChange={(event) =>
                  handleDateChange(event.target.value)
                }
                className="h-12 w-full rounded-xl border border-[#e5e3da] bg-white px-3 text-sm text-[#20251f] outline-none transition focus:border-[#55735b] focus:ring-2 focus:ring-[#55735b]/10"
              />
            </label>

            {/* Time */}
            <label className="block">
              <span className="mb-2 block text-xs font-semibold text-[#4d554b]">
                Reservation time
              </span>

              <select
                value={time}
                onChange={(event) =>
                  handleTimeChange(event.target.value)
                }
                className="h-12 w-full rounded-xl border border-[#e5e3da] bg-white px-3 text-sm text-[#20251f] outline-none transition focus:border-[#55735b] focus:ring-2 focus:ring-[#55735b]/10"
              >
                {reservationTimes.map((slot) => (
                  <option key={slot.value} value={slot.value}>
                    {slot.label}
                  </option>
                ))}
              </select>
            </label>

            {/* Guests */}
            <label className="block">
              <span className="mb-2 block text-xs font-semibold text-[#4d554b]">
                Number of guests
              </span>

              <select
                value={guests}
                onChange={(event) =>
                  handleGuestsChange(event.target.value)
                }
                className="h-12 w-full rounded-xl border border-[#e5e3da] bg-white px-3 text-sm text-[#20251f] outline-none transition focus:border-[#55735b] focus:ring-2 focus:ring-[#55735b]/10"
              >
                {[1, 2, 3, 4, 5, 6].map((count) => (
                  <option key={count} value={count}>
                    {count} {count === 1 ? "guest" : "guests"}
                  </option>
                ))}
              </select>
            </label>
          </div>
        </section>

        {/* Restaurant floor plan */}
        <RestaurantFloorPlan
          guests={guests}
          selectedTableId={selectedTableId}
          onSelect={handleTableSelect}
        />

        {/* Reservation summary */}
        <section className="mt-6 rounded-[20px] border border-[#e5e3da] bg-white p-5 sm:p-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[1.5px] text-[#85877e]">
                Reservation summary
              </p>

              <p className="mt-2 text-sm font-semibold text-[#20251f]">
                {restaurantName}
              </p>

              <p className="mt-1 text-xs text-[#777d73]">
                {date || "Choose a date"} · {time || "Choose a time"} ·{" "}
                {guests} {guests === 1 ? "guest" : "guests"}
              </p>

              <p className="mt-1 text-xs text-[#777d73]">
                {selectedTableId
                  ? `Selected: ${selectedTableId}`
                  : "No table selected"}
              </p>
            </div>

            <button
              type="button"
              onClick={handleContinue}
              disabled={
                !selectedTableId ||
                !date ||
                date < today ||
                !time
              }
              className="inline-flex min-h-12 items-center justify-center rounded-full bg-[#244b38] px-7 py-3 text-sm font-semibold text-white transition hover:bg-[#183727] disabled:cursor-not-allowed disabled:bg-[#a8b2a9]"
            >
              Continue to reservation
              <span className="ml-2" aria-hidden="true">
                →
              </span>
            </button>
          </div>

          {/* Validation error */}
          {error && (
            <p
              role="alert"
              className="mt-4 rounded-xl border border-[#f0d0c8] bg-[#fff5f1] px-4 py-3 text-sm text-[#a33d31]"
            >
              {error}
            </p>
          )}
        </section>

        {/* Prototype notice */}
        <p className="mt-5 text-center text-[10px] leading-5 text-[#999b92]">
          Table layouts and availability are sample data for this
          prototype. Reservation availability is not confirmed until
          verified by the backend.
        </p>
      </div>
    </main>
  );
}

export default function AvailabilityPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center bg-[#f8f8f3]">
          <p className="text-sm text-[#697066]">
            Loading table availability...
          </p>
        </main>
      }
    >
      <AvailabilityContent />
    </Suspense>
  );
}