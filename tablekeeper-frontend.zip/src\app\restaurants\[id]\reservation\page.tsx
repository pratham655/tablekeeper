"use client";

import { use } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

type Restaurant = {
  id: number;
  name: string;
  cuisine: string;
  location: string;
  price: string;
  image: string;
  rating?: number;
  reviews?: number;
};

const restaurants: Restaurant[] = [
  {
    id: 1,
    name: "The Olive Table",
    cuisine: "Mediterranean",
    location: "Indiranagar, Bengaluru",
    price: "₹₹₹",
    image:
      "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 2,
    name: "Spice Route",
    cuisine: "Indian",
    location: "Koramangala, Bengaluru",
    price: "₹₹",
    image:
      "https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 3,
    name: "Sakura House",
    cuisine: "Japanese",
    location: "MG Road, Bengaluru",
    price: "₹₹₹₹",
    image:
      "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 4,
    name: "Casa Verde",
    cuisine: "Italian",
    location: "Whitefield, Bengaluru",
    price: "₹₹₹",
    image:
      "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 5,
    name: "The Terrace",
    cuisine: "Continental",
    location: "HSR Layout, Bengaluru",
    price: "₹₹₹",
    image:
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 6,
    name: "Chai & Co.",
    cuisine: "Indian",
    location: "Jayanagar, Bengaluru",
    price: "₹₹",
    image:
      "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1600&q=80",
  },
  {
    id: 7,
    name: "DRUMA",
    cuisine: "Vegetarian Multi-cuisine",
    location: "Jayanagar, Bengaluru",
    price: "—",
    rating: 3.9,
    reviews: 2608,
    image:
      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1600&q=80",
  },
];

export default function ReservationPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const router = useRouter();
  const searchParams = useSearchParams();

  const restaurant = restaurants.find(
    (item) => item.id === Number(id)
  );

  const date = searchParams.get("date") || "";
  const time = searchParams.get("time") || "";
  const guests = searchParams.get("guests") || "2";
  const tableId = searchParams.get("table") || "T01";
  const tableSeats = searchParams.get("seats") || "2";

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [specialRequest, setSpecialRequest] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!restaurant) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#faf9f7] px-6">
        <div className="text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#1f3d2b] text-2xl font-bold text-white">
            ?
          </div>

          <h1 className="mt-6 text-2xl font-bold">
            Restaurant not found
          </h1>

          <p className="mt-2 text-sm text-black/45">
            The restaurant you are looking for does not exist.
          </p>

          <button
            onClick={() => router.push("/")}
            className="mt-6 rounded-full bg-[#1f3d2b] px-6 py-3 text-sm font-bold text-white"
          >
            Back to restaurants
          </button>
        </div>
      </main>
    );
  }

  const handleConfirmReservation = () => {
    if (isSubmitting) return;

    setErrorMessage("");

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedPhone = phone.trim();
    const trimmedRequest = specialRequest.trim();

    if (
      trimmedName.length < 2 ||
      !/^[\p{L}\p{M}][\p{L}\p{M}\s.'-]*$/u.test(trimmedName)
    ) {
      setErrorMessage("Please enter a valid full name.");
      return;
    }

    if (
      trimmedEmail.length > 254 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)
    ) {
      setErrorMessage("Please enter a valid email address.");
      return;
    }

    const normalizedPhone = trimmedPhone.replace(/[\s().-]/g, "");

    const isIndianMobile = /^[6-9]\d{9}$/.test(normalizedPhone);
    const isInternationalPhone = /^\+[1-9]\d{6,14}$/.test(normalizedPhone);

    if (!isIndianMobile && !isInternationalPhone) {
      setErrorMessage(
        "Enter a valid phone number. Use a 10-digit Indian mobile number or an international number with its country code (e.g. +14155552671)."
      );
      return;
    }

    if (!date || !time) {
      setErrorMessage(
        "Reservation date and time are missing. Please go back and select them again."
      );
      return;
    }

    const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
    const timeMatch = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(time);

    if (!dateMatch || !timeMatch) {
      setErrorMessage(
        "Please select a valid reservation date and time."
      );
      return;
    }

    const year = Number(dateMatch[1]);
    const month = Number(dateMatch[2]);
    const day = Number(dateMatch[3]);
    const hours = Number(timeMatch[1]);
    const minutes = Number(timeMatch[2]);

    const selectedDate = new Date(year, month - 1, day);

    if (
      selectedDate.getFullYear() !== year ||
      selectedDate.getMonth() !== month - 1 ||
      selectedDate.getDate() !== day
    ) {
      setErrorMessage("Please select a valid calendar date.");
      return;
    }

    const now = new Date();
    const today = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate()
    );

    if (selectedDate < today) {
      setErrorMessage("Please select today or a future date.");
      return;
    }

    const selectedDateTime = new Date(
      year,
      month - 1,
      day,
      hours,
      minutes
    );

    if (selectedDateTime <= now) {
      setErrorMessage(
        "That time has already passed. Please select a future time."
      );
      return;
    }

    const guestCount = Number(guests);
    const capacity = Number(tableSeats);

    if (
      !Number.isInteger(guestCount) ||
      guestCount < 1 ||
      !Number.isInteger(capacity) ||
      capacity < guestCount
    ) {
      setErrorMessage(
        "The selected table may not have enough seats. Please return to availability and choose another table."
      );
      return;
    }

    if (trimmedRequest.length > 500) {
      setErrorMessage("Special requests must be 500 characters or fewer.");
      return;
    }

    const reservationData = {
      restaurantId: restaurant.id,
      restaurantName: restaurant.name,
      date,
      time,
      guests: String(guestCount),
      tableId,
      tableSeats: String(capacity),
      name: trimmedName,
      email: trimmedEmail,
      phone: normalizedPhone,
      specialRequest: trimmedRequest,
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    try {
      setIsSubmitting(true);

      sessionStorage.setItem(
        "tablekeeper_pending_reservation",
        JSON.stringify(reservationData)
      );

      router.push(
        `/reservation-confirmed?restaurant=${encodeURIComponent(
          restaurant.name
        )}&date=${encodeURIComponent(date)}&time=${encodeURIComponent(
          time
        )}&guests=${encodeURIComponent(
          String(guestCount)
        )}&table=${encodeURIComponent(tableId)}&name=${encodeURIComponent(
          trimmedName
        )}`
      );
    } catch {
      setIsSubmitting(false);
      setErrorMessage(
        "We couldn't save your reservation request in this browser. Please try again."
      );
    }
  };

  return (
    <main className="min-h-screen bg-[#faf9f7] text-[#1d1d1b]">
      {/* NAVBAR */}
      <header className="sticky top-0 z-50 border-b border-black/5 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-10">
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-3"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#1f3d2b] text-xl text-white">
              T
            </div>

            <div className="text-left">
              <h1 className="text-xl font-bold tracking-tight">
                Tablekeeper
              </h1>

              <p className="hidden text-[10px] font-medium uppercase tracking-[0.22em] text-black/45 sm:block">
                Restaurant Reservations
              </p>
            </div>
          </button>

          <button
            onClick={() =>
              router.push(
                `/restaurants/${restaurant.id}/availability?date=${encodeURIComponent(
                  date
                )}&time=${encodeURIComponent(
                  time
                )}&guests=${encodeURIComponent(guests)}`
              )
            }
            className="rounded-full border border-black/10 bg-white px-5 py-2.5 text-sm font-semibold transition hover:border-[#1f3d2b] hover:text-[#1f3d2b]"
          >
            Back to availability
          </button>
        </div>
      </header>

      {/* PAGE HEADER */}
      <section className="border-b border-black/5 bg-white">
        <div className="mx-auto max-w-7xl px-5 py-10 sm:px-8 lg:px-10">
          <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#1f3d2b]/60">
            Complete your reservation
          </p>

          <h2 className="mt-3 text-4xl font-bold tracking-tight sm:text-5xl">
            Reservation details
          </h2>

          <p className="mt-3 max-w-2xl text-sm leading-6 text-black/50">
            Enter your contact details and review your reservation
            before confirming your table.
          </p>
        </div>
      </section>

      {/* CONTENT */}
      <section className="mx-auto max-w-7xl px-5 py-10 sm:px-8 lg:px-10">
        <div className="grid gap-8 lg:grid-cols-[1fr_400px]">
          {/* FORM */}
          <div>
            <div className="rounded-3xl border border-black/5 bg-white p-6 shadow-sm sm:p-8">
              <h3 className="text-xl font-bold">
                Your details
              </h3>

              <p className="mt-2 text-sm text-black/45">
                We need these details to create your reservation.
              </p>

              {/* NAME */}
              <div className="mt-7">
                <label
                  htmlFor="name"
                  className="text-sm font-bold"
                >
                  Full name
                </label>

                <input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setErrorMessage("");
                  }}
                  placeholder="Enter your full name"
                  maxLength={100}
                  className="mt-2 w-full rounded-2xl border border-black/10 bg-[#faf9f7] px-4 py-3.5 text-sm outline-none transition focus:border-[#1f3d2b]"
                />
              </div>

              {/* EMAIL */}
              <div className="mt-5">
                <label
                  htmlFor="email"
                  className="text-sm font-bold"
                >
                  Email address
                </label>

                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setErrorMessage("");
                  }}
                  placeholder="you@example.com"
                  maxLength={254}
                  className="mt-2 w-full rounded-2xl border border-black/10 bg-[#faf9f7] px-4 py-3.5 text-sm outline-none transition focus:border-[#1f3d2b]"
                />
              </div>

              {/* PHONE */}
              <div className="mt-5">
                <label
                  htmlFor="phone"
                  className="text-sm font-bold"
                >
                  Phone number
                </label>

                <input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                    setErrorMessage("");
                  }}
                  placeholder="+91 98765 43210 or +1 415 555 2671"
                  maxLength={25}
                  className="mt-2 w-full rounded-2xl border border-black/10 bg-[#faf9f7] px-4 py-3.5 text-sm outline-none transition focus:border-[#1f3d2b]"
                />
              </div>

              {/* SPECIAL REQUEST */}
              <div className="mt-5">
                <label
                  htmlFor="request"
                  className="text-sm font-bold"
                >
                  Special requests
                  <span className="ml-2 font-normal text-black/35">
                    Optional
                  </span>
                </label>

                <textarea
                  id="request"
                  value={specialRequest}
                  onChange={(e) =>
                    setSpecialRequest(e.target.value)
                  }
                  placeholder="Birthday celebration, window seat, dietary request..."
                  maxLength={500}
                  rows={4}
                  className="mt-2 w-full resize-none rounded-2xl border border-black/10 bg-[#faf9f7] px-4 py-3.5 text-sm outline-none transition focus:border-[#1f3d2b]"
                />
              </div>

              {/* ERROR */}
              {errorMessage && (
                <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 p-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-red-100 font-bold text-red-600">
                      !
                    </div>

                    <div>
                      <p className="text-sm font-bold text-red-700">
                        Please check your details
                      </p>

                      <p className="mt-1 text-xs leading-5 text-red-600/80">
                        {errorMessage}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* CONFIRM */}
              <button
                type="button"
                onClick={handleConfirmReservation}
                disabled={isSubmitting}
                className="mt-7 w-full rounded-2xl bg-[#1f3d2b] py-4 text-sm font-bold text-white transition hover:bg-[#173020] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {isSubmitting ? "Submitting..." : "Confirm reservation"}
              </button>
            </div>
          </div>

          {/* RESERVATION SUMMARY */}
          <aside className="lg:sticky lg:top-28 lg:self-start">
            <div className="overflow-hidden rounded-3xl border border-black/5 bg-white shadow-sm">
              <img
                src={restaurant.image}
                alt={restaurant.name}
                className="h-52 w-full object-cover"
              />

              <div className="p-6">
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-black/35">
                  Reservation summary
                </p>

                <h3 className="mt-2 text-2xl font-bold">
                  {restaurant.name}
                </h3>

                <p className="mt-1 text-sm text-black/45">
                  {restaurant.cuisine} · {restaurant.location}
                </p>
                {restaurant.rating !== undefined && (
                  <p className="mt-2 flex items-center gap-1.5 text-sm text-black/60">
                    <span aria-hidden="true" className="text-amber-500">★</span>
                    <span className="font-semibold text-[#20251f]">{restaurant.rating.toFixed(1)}</span>
                    {restaurant.reviews !== undefined && (
                      <span>({restaurant.reviews.toLocaleString("en-IN")} ratings)</span>
                    )}
                  </p>
                )}

                <div className="my-6 h-px bg-black/5" />

                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-black/35">
                        Date
                      </p>
                      <p className="mt-1 text-sm font-bold">
                        {date || "Not selected"}
                      </p>
                    </div>

                    <span className="text-lg">📅</span>
                  </div>

                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-black/35">
                        Time
                      </p>
                      <p className="mt-1 text-sm font-bold">
                        {time || "Not selected"}
                      </p>
                    </div>

                    <span className="text-lg">🕐</span>
                  </div>

                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-black/35">
                        Guests
                      </p>
                      <p className="mt-1 text-sm font-bold">
                        {guests} guests
                      </p>
                    </div>

                    <span className="text-lg">👥</span>
                  </div>

                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-xs text-black/35">
                        Table
                      </p>
                      <p className="mt-1 text-sm font-bold">
                        {tableId}
                      </p>
                      <p className="text-xs text-black/40">
                        Up to {tableSeats} guests
                      </p>
                    </div>

                    <span className="text-lg">🍽</span>
                  </div>
                </div>

                <div className="mt-6 rounded-2xl bg-[#f1f5f1] p-4">
                  <p className="text-xs font-bold text-[#1f3d2b]">
                    Your selected table and time
                  </p>

                  <p className="mt-1 text-[11px] leading-5 text-black/45">
                    Review your reservation details before submitting
                    your request.
                  </p>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1f3d2b] text-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 sm:px-8 lg:flex-row lg:items-center lg:justify-between lg:px-10">
          <div>
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white text-sm font-bold text-[#1f3d2b]">
                T
              </div>

              <span className="font-bold">
                Tablekeeper
              </span>
            </div>

            <p className="mt-3 text-xs text-white/45">
              Restaurant reservations, made simple.
            </p>
          </div>

          <p className="text-xs text-white/35">
            © 2026 Tablekeeper. All rights reserved.
          </p>
        </div>
      </footer>
    </main>
  );
}