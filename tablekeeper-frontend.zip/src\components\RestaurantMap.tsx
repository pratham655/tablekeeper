"use client";

import "leaflet/dist/leaflet.css";
import { useMemo } from "react";
import { MapContainer, Marker, Popup, TileLayer } from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-cluster";
import L from "leaflet";

type MapRestaurant = {
  id: number;
  name: string;
  cuisine: string;
  location: string;
  rating: number;
  reviews: number;
  price: string;
  image: string;
  tags: string[];
};

type Props = { restaurants: MapRestaurant[] };

// These are neighbourhood-level reference points for the demo, not venue coordinates.
const neighbourhoodCoordinates: Record<string, [number, number]> = {
  Indiranagar: [12.9784, 77.6408],
  Koramangala: [12.9352, 77.6245],
  "MG Road": [12.9756, 77.6066],
  Whitefield: [12.9698, 77.7500],
  "HSR Layout": [12.9116, 77.6389],
  Jayanagar: [12.9250, 77.5838],
};

function makeRestaurantIcon() {
  return L.divIcon({
    className: "tablekeeper-map-marker-wrap",
    html: '<span class="tablekeeper-map-marker"><span></span></span>',
    iconSize: [34, 42],
    iconAnchor: [17, 38],
    popupAnchor: [0, -36],
  });
}

export default function RestaurantMap({ restaurants }: Props) {
  const icon = useMemo(() => makeRestaurantIcon(), []);
  const locatedRestaurants = useMemo(
    () =>
      restaurants.flatMap((restaurant) => {
        const neighbourhood = Object.keys(neighbourhoodCoordinates).find((key) =>
          restaurant.location.toLowerCase().includes(key.toLowerCase()),
        );
        if (!neighbourhood) return [];
        return [{
          ...restaurant,
          position: neighbourhoodCoordinates[neighbourhood],
        }];
      }),
    [restaurants],
  );

  return (
    <div className="relative h-[420px] overflow-hidden rounded-[15px] sm:h-[520px]">
      <MapContainer
        center={[12.9716, 77.5946]}
        zoom={11}
        minZoom={10}
        maxZoom={18}
        scrollWheelZoom={false}
        className="h-full w-full"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MarkerClusterGroup
          chunkedLoading
          showCoverageOnHover={false}
          maxClusterRadius={48}
        >
          {locatedRestaurants.map((restaurant) => (
            <Marker
              key={restaurant.id}
              position={restaurant.position}
              icon={icon}
              title={restaurant.name}
              alt={restaurant.name}
            >
              <Popup>
                <div className="w-[210px] overflow-hidden text-[#20251f]">
                  <img
                    src={restaurant.image}
                    alt={restaurant.name}
                    className="mb-3 h-[105px] w-full rounded-lg object-cover"
                    loading="lazy"
                  />
                  <p className="font-serif text-lg leading-tight">{restaurant.name}</p>
                  <p className="mt-1 text-xs text-[#777d73]">
                    {restaurant.cuisine} · {restaurant.location.split(",")[0]}
                  </p>
                  <p className="mt-2 text-xs text-[#777d73]">
                    {restaurant.rating > 0 ? `★ ${restaurant.rating.toFixed(1)} · ${restaurant.reviews} reviews` : "Rating not yet available"}
                    {restaurant.price !== "—" ? ` · ${restaurant.price}` : ""}
                  </p>
                  <a
                    href={`/restaurants/${restaurant.id}`}
                    className="mt-3 inline-flex text-xs font-semibold text-[#244b38] underline underline-offset-2"
                  >
                    View restaurant →
                  </a>
                </div>
              </Popup>
            </Marker>
          ))}
        </MarkerClusterGroup>
      </MapContainer>
      {locatedRestaurants.length === 0 && (
        <div className="absolute inset-x-4 top-4 z-[1000] rounded-xl bg-white/95 px-4 py-3 text-center text-xs text-[#777d73] shadow">
          No restaurants with mapped neighbourhoods match these filters.
        </div>
      )}
    </div>
  );
}
