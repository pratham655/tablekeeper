
"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";

function ReservationConfirmedContent() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const restaurant =
    searchParams.get("restaurant") || "Restaurant";

  const date = searchParams.get("date") || "";
  const time = searchParams.get("time") || "";
  const guests = searchParams.get("guests") || "2";
  const table = searchParams.get("table") || "T01";
  const name = searchParams.get("name") || "Guest";

  const [confirmationNumber, setConfirmationNumber] = useState("");

  useEffect(() => {
    const bookingKey = `tablekeeper_confirmation_${restaurant}_${date}_${time}_${guests}_${table}_${name}`;

    let savedNumber = sessionStorage.getItem(bookingKey);

    if (!savedNumber) {
      savedNumber = `TK-${Math.floor(
        10000000 + Math.random() * 90000000
      )}`;

      sessionStorage.setItem(bookingKey, savedNumber);
    }

    setConfirmationNumber(savedNumber);
  }, [restaurant, date, time, guests, table, name]);

  return (
    <main className="min-h-screen bg-[#faf9f7] text-[#1d1d1b]">
      {/* NAVBAR */}
      <header className="border-b border-black/5 bg-white">
        <div className="mx-auto flex h-20 max-w-7xl items-center px-5 sm:px-8 lg:px-10">
          <button
            type="button"
            onClick={() => router.push("/")}
            className="flex items-center gap-3"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#1f3d2b] text-xl text-white">
              T
            </div>

            <div className="text-left">
              <h1 className="text-xl font-bold tracking-tight">
                Tablekeeper
              </h1>

              <p className="hidden text-[10px] font-medium uppercase tracking-[0.22em] text-black/45 sm:block">
                Restaurant Reservations
              </p>
            </div>
          </button>
        </div>
      </header>

      {/* CONFIRMATION */}
      <section className="mx-auto flex min-h-[calc(100vh-80px)] max-w-3xl items-center px-5 py-16 sm:px-8">
        <div className="w-full rounded-[32px] border border-black/5 bg-white p-7 text-center shadow-sm sm:p-12">
          {/* SUCCESS ICON */}
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-[#1f3d2b] text-3xl text-white">
            ✓
          </div>

          <p className="mt-7 text-xs font-bold uppercase tracking-[0.2em] text-[#1f3d2b]/60">
            Reservation request received
          </p>

          <h1 className="mt-3 text-4xl font-bold tracking-tight sm:text-5xl">
            You're all set, {name.split(" ")[0]}!
          </h1>

          <p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-black/50">
            We've received your reservation request. Please review
            the details below. Your table's availability will be
            confirmed once the restaurant processes your request.
          </p>

          {/* REFERENCE NUMBER */}
          <div className="mx-auto mt-7 inline-flex rounded-full bg-[#f1f5f1] px-5 py-3">
            <span className="text-xs font-bold tracking-wider text-[#1f3d2b]">
              REFERENCE {confirmationNumber || "Generating..."}
            </span>
          </div>

          {/* DETAILS */}
          <div className="mt-10 rounded-3xl bg-[#faf9f7] p-6 text-left sm:p-7">
            <h2 className="text-lg font-bold">
              Reservation details
            </h2>

            <div className="mt-6 grid gap-5 sm:grid-cols-2">
              <div>
                <p className="text-xs text-black/35">
                  Restaurant
                </p>
                <p className="mt-1 text-sm font-bold">
                  {restaurant}
                </p>
              </div>

              <div>
                <p className="text-xs text-black/35">
                  Table
                </p>
                <p className="mt-1 text-sm font-bold">
                  {table}
                </p>
              </div>

              <div>
                <p className="text-xs text-black/35">
                  Date
                </p>
                <p className="mt-1 text-sm font-bold">
                  {date || "Not specified"}
                </p>
              </div>

              <div>
                <p className="text-xs text-black/35">
                  Time
                </p>
                <p className="mt-1 text-sm font-bold">
                  {time || "Not specified"}
                </p>
              </div>

              <div>
                <p className="text-xs text-black/35">
                  Guests
                </p>
                <p className="mt-1 text-sm font-bold">
                  {guests} {guests === "1" ? "guest" : "guests"}
                </p>
              </div>

              <div>
                <p className="text-xs text-black/35">
                  Status
                </p>
                <p className="mt-1 text-sm font-bold text-[#1f3d2b]">
                  Request received
                </p>
              </div>
            </div>
          </div>

          {/* ACTIONS */}
          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            <button
              type="button"
              onClick={() => router.push("/reservations")}
              className="rounded-2xl bg-[#1f3d2b] py-4 text-sm font-bold text-white transition hover:bg-[#173020]"
            >
              My reservations
            </button>

            <button
              type="button"
              onClick={() => router.push("/")}
              className="rounded-2xl border border-black/10 bg-white py-4 text-sm font-bold text-black/60 transition hover:border-[#1f3d2b] hover:text-[#1f3d2b]"
            >
              Discover restaurants
            </button>
          </div>

          {/* THANK YOU MESSAGE */}
          <p className="mx-auto mt-4 max-w-xl text-sm leading-6 text-black/50">
            Thank you for choosing Tablekeeper. Keep your
            reference number handy if you need to view your
            reservation request later.
          </p>
        </div>
      </section>
    </main>
  );
}

export default function ReservationConfirmedPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center bg-[#f8f7f2]">
          <p className="text-sm text-[#777d73]">
            Loading your reservation...
          </p>
        </main>
      }
    >
      <ReservationConfirmedContent />
    </Suspense>
  );
}